SafarSathi Bus Ticket Booking System - Production Package
Extract all files into public_html/.
Database is pre-configured with u798858760_safarsathi123.
Admin Portal: https://yourdomain.com/admin (admin@safarsathi.com / amir2010khan)
